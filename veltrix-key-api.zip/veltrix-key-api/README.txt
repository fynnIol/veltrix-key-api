VELTRIX KEY API SETUP

1. Create a free account at vercel.com.
2. Upload this folder to a new GitHub repo, or install Vercel CLI and deploy this folder.
3. In Vercel, open your project.
4. Go to Settings > Environment Variables.
5. Add these variables:

SUPABASE_URL=your Supabase project URL
SUPABASE_SERVICE_ROLE_KEY=your Supabase service_role key

IMPORTANT:
Never put your service_role key inside your userscript.
Only put it in Vercel environment variables.

Where to find Supabase values:
Supabase project > Project Settings > API
- Project URL = SUPABASE_URL
- service_role secret = SUPABASE_SERVICE_ROLE_KEY

Your API endpoint after deployment will be:
https://YOUR-VERCEL-PROJECT.vercel.app/api/check-key

USERSCRIPT EXAMPLE:

async function checkVeltrixKey(key) {
  const userLock = navigator.userAgent;

  const res = await fetch("https://YOUR-VERCEL-PROJECT.vercel.app/api/check-key", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      key,
      used_by: userLock
    })
  });

  const data = await res.json();
  return data.valid === true;
}

if (await checkVeltrixKey(enteredKey)) {
  loadMainScript();
} else {
  alert("Invalid key");
}
